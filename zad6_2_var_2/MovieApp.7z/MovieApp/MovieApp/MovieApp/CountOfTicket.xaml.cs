﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MovieApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CountOfTicket : ContentPage
    {
        public CountOfTicket(Movie movie)
        {
            InitializeComponent();
            name.Text = movie.Name;
            summary.Text = movie.Summary;
            photo.Source = movie.Photo;
            Back.Clicked += async (sender, e) =>
            {
                await Navigation.PopAsync();
            };
            SumButton.Clicked += async (sender, e) =>
            {
                if (string.IsNullOrEmpty(CountTicket.Text) || int.Parse(CountTicket.Text) == 0)
                {
                    await DisplayAlert("Ошибка", "Введите количество билетов", "Ок");
                }
                else if (int.Parse(CountTicket.Text) > movie.Capacity)
                {
                    await DisplayAlert("Ошибка", "Количество билетов не может быть больше вместимости", "Ок");
                }
                else
                {
                    await Navigation.PushModalAsync(new PriceCalculation(int.Parse(CountTicket.Text), movie));
                }
            };
        }
    }
}