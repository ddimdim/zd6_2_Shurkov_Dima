﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp
{
    public class Movie
    {
        public string Name { get; set; }
        public string Photo { get; set; }
        public string Studio { get; set; }
        public string Category { get; set; }
        public int Capacity { get; set; }
        public string Cinema { get; set; }
        public int Hall { get; set; }
        public int Seat { get; set; }
        public string Time { get; set; }
        public string Date { get; set; }
        public string Director { get; set; }
        public int Year { get; set; }
        public string Country { get; set; }
        public string Summary { get; set; }
        public double TicketPrice { get; set; }
        
    }
}
