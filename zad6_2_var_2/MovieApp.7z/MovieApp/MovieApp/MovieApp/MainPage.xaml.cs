﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MovieApp
{
    public partial class MainPage : CarouselPage
    { 
        List<Movie> movies;
        public MainPage()
        {
            InitializeComponent();
            movies = new List<Movie>
            {
                new Movie
                {
                    Name = "Матрица",
                    Photo = "m1.png",
                    Studio = "Warner Bros",
                    Category = "Научная фантастика",
                    Capacity = 100,
                    Cinema = "Прайм",
                    Hall = 3,
                    Seat = 9,
                    Time = "17:00",
                    Date = "23.06.2023",
                    Director = "Лана Вачовски, Лилли Вачовски",
                    Year = 1999,
                    Country = "США",
                    Summary = "Программист Нео обнаруживает, что мир, в котором он живет, на самом деле является компьютерной симуляцией...",
                    TicketPrice = 350

                },
                new Movie
                {
                    Name = "Побег из Шоушенка",
                    Photo = "m2.png",
                    Studio = "Columbia Pictures",
                    Category = "Криминал",
                    Capacity = 110,
                    Cinema = "Премьер",
                    Hall = 4,
                    Seat = 12,
                    Time = "15:00",
                    Date = "23.06.2023",
                    Director = "Фрэнк Дарабонт",
                    Year = 1994,
                    Country = "США",
                    Summary = "Умный заключенный Анди Дюфрейнт находит способ сбежать из тюрьмы...",
                    TicketPrice = 400

                },
                new Movie
                {
                    Name = "Зеленая миля",
                    Photo = "m3.png",
                    Studio = "Castle Rock Entertainment",
                    Category = "Драма",
                    Capacity = 120,
                    Cinema = "Прайм",
                    Hall = 1,
                    Seat = 6,
                    Time = "20:00",
                    Date = "23.06.2023",
                    Director = "Фрэнк Дарабонт",
                    Year = 1999,
                    Country = "США",
                    Summary = "Сотрудники тюрьмы сталкиваются с загадочным заключенным с необычными способностями...",
                    TicketPrice = 400
                },
                new Movie
                {
                    Name = "Титаник",
                    Photo = "m4.png",
                    Studio = "20th Century Fox",
                    Category = "Драма",
                    Capacity = 100,
                    Cinema = "Прайм",
                    Hall = 4,
                    Seat = 10,
                    Time = "10:00",
                    Date = "23.06.2023",
                    Director = "Джеймс Кэмерон",
                    Year = 1997,
                    Country = "США",
                    Summary = "Романтическая история о любви между пассажирами Титаника...",
                    TicketPrice = 300
                }

            };

            
            film1_1.Text = $"Фильм: {movies[0].Name}";
            film1_2.Text = $"Студия: {movies[0].Studio}";
            film1_3.Text = $"Категория: {movies[0].Category}";
            film1_4.Text = $"Вместимость: {movies[0].Capacity}";
            film1_5.Text = $"Кинотеатр: {movies[0].Cinema}";
            film1_6.Text = $"Зал: {movies[0].Hall}";
            film1_7.Text = $"Место: {movies[0].Seat}";
            film1_8.Text = $"Время: {movies[0].Time}";
            film1_9.Text = $"Дата: {movies[0].Date}";
            film1_10.Text = $"Режиссер: {movies[0].Director}";
            film1_11.Text = $"Год выпуска: {movies[0].Year}";
            film1_12.Text = $"Страна: {movies[0].Country}";
            film1_13.Text = $"{movies[0].Summary}";
            film1_14.Text = $"Цена билета: {movies[0].TicketPrice} рублей";
            mov1.Source = movies[0].Photo;

            film2_1.Text = $"Фильм: {movies[1].Name}";
            film2_2.Text = $"Студия: {movies[1].Studio}";
            film2_3.Text = $"Категория: {movies[1].Category}";
            film2_4.Text = $"Вместимость: {movies[1].Capacity}";
            film2_5.Text = $"Кинотеатр: {movies[1].Cinema}";
            film2_6.Text = $"Зал: {movies[1].Hall}";
            film2_7.Text = $"Место: {movies[1].Seat}";
            film2_8.Text = $"Время: {movies[1].Time}";
            film2_9.Text = $"Дата: {movies[1].Date}";
            film2_10.Text = $"Режиссер: {movies[1].Director}";
            film2_11.Text = $"Год выпуска: {movies[1].Year}";
            film2_12.Text = $"Страна: {movies[1].Country}";
            film2_13.Text = $"{movies[1].Summary}";
            film2_14.Text = $"Цена билета: {movies[1].TicketPrice} рублей";
            mov2.Source = movies[1].Photo;

            film3_1.Text = $"Фильм: {movies[2].Name}";
            film3_2.Text = $"Студия: {movies[2].Studio}";
            film3_3.Text = $"Категория: {movies[2].Category}";
            film3_4.Text = $"Вместимость: {movies[2].Capacity}";
            film3_5.Text = $"Кинотеатр: {movies[2].Cinema}";
            film3_6.Text = $"Зал: {movies[2].Hall}";
            film3_7.Text = $"Место: {movies[2].Seat}";
            film3_8.Text = $"Время: {movies[2].Time}";
            film3_9.Text = $"Дата: {movies[2].Date}";
            film3_10.Text = $"Режиссер: {movies[2].Director}";
            film3_11.Text = $"Год выпуска: {movies[2].Year}";
            film3_12.Text = $"Страна: {movies[2].Country}";
            film3_13.Text = $"{movies[2].Summary}";
            film3_14.Text = $"Цена билета: {movies[2].TicketPrice} рублей";
            mov3.Source = movies[2].Photo;

            film4_1.Text = $"Фильм: {movies[3].Name}";
            film4_2.Text = $"Студия: {movies[3].Studio}";
            film4_3.Text = $"Категория: {movies[3].Category}";
            film4_4.Text = $"Вместимость: {movies[3].Capacity}";
            film4_5.Text = $"Кинотеатр: {movies[3].Cinema}";
            film4_6.Text = $"Зал: {movies[3].Hall}";
            film4_7.Text = $"Место: {movies[3].Seat}";
            film4_8.Text = $"Время: {movies[3].Time}";
            film4_9.Text = $"Дата: {movies[3].Date}";
            film4_10.Text = $"Режиссер: {movies[3].Director}";
            film4_11.Text = $"Год выпуска: {movies[3].Year}";
            film4_12.Text = $"Страна: {movies[3].Country}";
            film4_13.Text = $"{movies[3].Summary}";
            film4_14.Text = $"Цена билета: {movies[3].TicketPrice} рублей";
            mov4.Source = movies[3].Photo;

            button1_1.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new CountOfTicket(movies[0]));
            };

            button2_1.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new CountOfTicket(movies[1]));
            };

            button3_1.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new CountOfTicket(movies[2]));
            };
            
            button4_1.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new CountOfTicket(movies[3]));
            };

            button1_2.Clicked += async (sender, e) =>
            {
                await Navigation.PushModalAsync(new PriceCalculation(1, movies[0]));
            };

            button2_2.Clicked += async (sender, e) =>
            {
                await Navigation.PushModalAsync(new PriceCalculation(1, movies[1]));
            };

            button3_2.Clicked += async (sender, e) =>
            {
                await Navigation.PushModalAsync(new PriceCalculation(1, movies[2]));
            };

            button4_2.Clicked += async (sender, e) =>
            {
                await Navigation.PushModalAsync(new PriceCalculation(1, movies[3]));
            };
        }

        
    }
}
