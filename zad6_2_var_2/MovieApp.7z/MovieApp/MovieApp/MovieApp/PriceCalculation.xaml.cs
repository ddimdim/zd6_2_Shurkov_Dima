﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MovieApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PriceCalculation : ContentPage
    {
        double itog = 0;
        public PriceCalculation(int countTicket, Movie movie)
        {
            
            InitializeComponent();
            bool family = true;
            name.Text = movie.Name;
            summary.Text = movie.Summary;
            price.Text = $"Цена 1-ого билета: {movie.TicketPrice} руб";
            result.Text = $"Дети (30%): ...\n" +
                          $"Пенсионеры (30%): ...\n" +
                          $"Студенты и учащиеся (20%): ...\n" +
                          $"Другие: ...\n" +
                          $"Многодетные семьи (10%) - ...\n" +
                          $"Общая стоимость: ...";
            calculate.Clicked += async (sender, e) =>
            {
                if (string.IsNullOrEmpty(childrens.Text) || string.IsNullOrEmpty(pensioners.Text) || string.IsNullOrEmpty(students.Text) || string.IsNullOrEmpty(People.Text))
                {
                    await DisplayAlert("Ошибка", "Введите все необходимые данные", "Ок");
                }
                else if (int.Parse(childrens.Text) + int.Parse(pensioners.Text) + int.Parse(students.Text) + int.Parse(People.Text) != countTicket)
                {
                    await DisplayAlert("Ошибка", $"Количество людей должно составлять: {countTicket}", "Ок");
                }
                else
                {
                    if (YesNo.IsToggled == false)
                    {
                        family = false;
                    }
                    else family = true;
                    double children = int.Parse(childrens.Text) * movie.TicketPrice * 0.7;
                    double pensioner = int.Parse(pensioners.Text) * movie.TicketPrice * 0.7;
                    double student = int.Parse(students.Text) * movie.TicketPrice * 0.8;
                    double people = int.Parse(People.Text) * movie.TicketPrice;
                    itog = children + pensioner + student + people;
                    if (family == true)
                    {
                        result.Text = $"Дети (30%): {children} руб\n" +
                          $"Пенсионеры (30%): {pensioner} руб\n" +
                          $"Студенты и учащиеся (20%): {student} руб\n" +
                          $"Другие: {people} руб\n" +
                          $"Многодетная семья (10%) - Да\n" +
                          $"Общая стоимость: {itog * 0.9} руб";
                    }
                    else
                    {
                        result.Text = $"Дети (30%): {children} руб\n" +
                          $"Пенсионеры (30%): {pensioner} руб\n" +
                          $"Студенты и учащиеся (20%): {student} руб\n" +
                          $"Другие: {people} руб\n" +
                          $"Многодетная семья (10%) - Нет\n" +
                          $"Общая стоимость: {itog} руб";
                    }
                    
                }

            };
            back.Clicked += async (sender, e) =>
            {
                    await Navigation.PushModalAsync(new MainPage());
            };

        }
    }
}